import React from "react";

export default function Logo() {
  return (
    <div className="logo1">
      <FontAwesomeIcon icon="fa-solid fa-user-group" />
      
    </div>
  );
}
