import React from "react";

function PageÜberUns() {
  return <div>PageÜberUns</div>;
}

export default PageÜberUns;
