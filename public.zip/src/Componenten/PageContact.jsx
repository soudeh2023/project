import React from "react";

function PageContact() {
  return <div>PageContact</div>;
}

export default PageContact;
